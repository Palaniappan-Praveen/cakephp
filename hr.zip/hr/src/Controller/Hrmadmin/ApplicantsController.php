<?php
namespace App\Controller\Hrmadmin;
use App\Controller\AppController;

    class  ApplicantsController extends AppController
    {
      #index function . It's default function
public function index($id)
{
	if(!empty($id)){
$this->set('applicants',$this->Applicants->find('all',['conditions'=>array('Applicants.vacancy_id'=>$id)])->contain('vacancies')); 
 
	}
}
#edit the view
public function edit($id)
{
   
	$applicants    = $this->Applicants->find('all', ['conditions' => ['applicant_id' => $id]])->contain('vacancies');
	$applicants    = $applicants->first();
     
	  if ($this->request->is(['post', 'put'])) {
	 
	  
      
	   $status           = trim($this->request->data('status'));
	  
	  $comment           = trim($this->request->data('comments'));
	  $data             =["status"=>$status,"comments"=>$comment];
      $vac              = $applicants['vacancy_id'];   
          $applicants= $this->Applicants->patchEntity($applicants, $data);
             
            if ($this->Applicants->save($applicants)) {

                $this->Flash->success(__('Applicants has been updated.'));

                return $this->redirect(["action"=>"index",$vac]);

            }
	  
	  $this->Flash->error(__('Unable to update Applicants.'));
	 
	 
	 
    }
	
	$this->set('applicants', $applicants); 
	



}

}
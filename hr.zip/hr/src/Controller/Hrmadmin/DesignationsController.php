<?php
namespace App\Controller\Hrmadmin;
use App\Controller\AppController;
use Cake\Event\Event;
    class DesignationsController extends AppController
    {

        
    
    

       #main function setting all value to view
    
      public function index()
       {
        $this->set('designation',$this->Designations->find('all')); 
       
       }
       
       #delete function, here we are deleting particular value 
       public function delete($id)

     {

        $this->request->allowMethod(['post', 'delete']);

     

        $designation = $this->Designations->get($id);

        if ($this->Designations->delete($designation)) {

            $this->Flash->success(__('The client with id: {0} has been deleted.', h($id)));

            return $this->redirect(['action' => 'index']);

        }      

         

    }  
    
    #edit function, and setting particular value for the view 
    public function edit($id)

    {

        $edit_designation = $this->Designations->get($id);

        if ($this->request->is(['post', 'put'])) {
        
        $designation_name = trim($this->request->data('designation_name'));
        $description      = trim($this->request->data('description'));
        $data=["designation_name"=>$designation_name,"description"=>$description ];

            $this->Designations->patchEntity($edit_designation, $data);

            if ($this->Designations->save($edit_designation)) {

                $this->Flash->success(__('Designation has been updated.'));

                return $this->redirect(['action' => 'index']);

            }

            $this->Flash->error(__('Unable to update designation.'));

        }

     

        $this->set('designations', $edit_designation);      

         

    }
    
    
    
    
     #add function,adding value into the database
    
  public function add()
       {
       
        $add_designation = $this->Designations->newEntity();
        if ($this->request->is('post')) {
        $designation_name = trim($this->request->data('designation_name'));
        $description      = trim($this->request->data('description'));
         
          
        
            $data=["designation_name"=>$designation_name,"description"=>$description ];
            
            #this function checks the validation
             $add_designation= $this->Designations->patchEntity($add_designation, $data);
            if($this->Designations->save($add_designation))
            {
              $this->Flash->success(__('The Desgination has been saved.'));
             return $this->redirect(['controller' => 'Designations',"action"=>"/"]);
            }
            else
            {
            $this->Flash->error(__('The Desgination cannot be saved.'));
            }
        
        
        }
       
       $this->set('designations', $add_designation);
       }
    }
    
    ?>
<?php
    namespace App\Controller\Hrmadmin;

    use App\Controller\AppController;

    class WelcomeController extends AppController
    {
      
	  public function index()
	   {  
	   
	     #setting page title 
		$this->set('pageTitle','Admin');
		#setting js script
		$this->set('scriptt',array());
		
		#getting and setting user attendance
		
		$uid     				= $this->Auth->user('employee_id');
		$currentdate            = date("Y-m-d");
		$role    				= $this->Auth->user('role');
		if($role=='employee' || $role=='admin')
		{
		if($uid)
		 {
			 $current_data   = $this->Welcome->Attendance->find('All',
                ['conditions'=>array('employee_id'=>$uid,'DATE(time_in)'=>$currentdate)]
        );
		
		  $number           = $current_data->count();
		  if($number>0)
		  {
		  $attendance_timein=$current_data->first()->time_in;
		  $attendance_timeout=$current_data->first()->time_out;
		  $this->set('timein',$attendance_timein);
		  $this->set('timeout',$attendance_timeout);
		  }
	     }
		else
		{
			return  $this->redirect($this->Auth->logout()); 
			
		}
		# including new template inside element/template.ctp
		
		}
		#setting data for hr
		
		 if($role=='hr' || $role=='admin' )
		{
		if($uid)
		 {
			 $current_data   = $this->Welcome->leaveRequests->find('All',['conditions'=>array('leaveRequests.status'=>0)])->contain(['employees']);
		
		  $number           = $current_data->count();
		  
		  if($number>0)
		  {
		  
		  $this->set('leave',$current_data);
		  }
	     }
		else
		{
			return  $this->redirect($this->Auth->logout()); 
			
		}
		# including new template inside element/template.ctp
		
		}
		
		
	   }
    }
	
	
	?>
<?php
namespace App\Controller\Hrmadmin;
use App\Controller\AppController;

    class ProjectsController extends AppController
    {
    
    
       #main function setting all value to view
    
      public function index()
       {
        $this->set('project',$this->Projects->find('all')); 
       
       }
       
       #delete function, here we are deleting particular value 
       public function delete($id)

     {

        $this->request->allowMethod(['post', 'delete']);

     

        $designation = $this->Projects->get($id);

        if ($this->Projects->delete($designation)) {

            $this->Flash->success(__('Project with id: {0} has been deleted.', h($id)));

            return $this->redirect(['action' => 'index']);

        }      

         

    }  
    
    #edit function, and setting particular value for the view 
    public function edit($id)

    {

        $edit_project = $this->Projects->get($id);

        if ($this->request->is(['post', 'put'])) {
        
        $project_title    = trim($this->request->data('project_title'));
        $description      = trim($this->request->data('description'));
        $start_date       = trim($this->request->data('start_date'));
        $end_date         = trim($this->request->data('end_date')); 
        $status           = trim($this->request->data('status'));
          
        
            $data=["project_title"=>$project_title,"description"=>$description,"start_date"=>$start_date,"end_date"=>$end_date,"status"=>$status];
            
             #this function checks the validation
             $edit_project = $this->Projects->patchEntity($edit_project, $data);

            if ($this->Projects->save($edit_project)) {

                $this->Flash->success(__('Project has been updated.'));

                return $this->redirect(['action' => 'index']);

            }

            $this->Flash->error(__('Unable to update Project.'));

        }

     

        $this->set('projects', $edit_project);      

         

    }
    
    
    
    
     #add function,adding value into the database
    
  public function add()
       {
       
        $add_project = $this->Projects->newEntity();
        if ($this->request->is('post')) {
        $project_title    = trim($this->request->data('project_title'));
        $description      = trim($this->request->data('description'));
        $start_date       = trim($this->request->data('start_date'));
        $end_date         = trim($this->request->data('end_date')); 
          
        
            $data=["project_title"=>$project_title,"description"=>$description,"start_date"=>$start_date,"end_date"=>$end_date];
            
             #this function checks the validation
             $add_project= $this->Projects->patchEntity($add_project, $data);
            if($this->Projects->save($add_project))
            {
              $this->Flash->success(__('Project has been saved.'));
             return $this->redirect(["action"=>"index"]);
            }
            else
            {
            $this->Flash->error(__('Project cannot be saved.'));
            }
        
        
        }
       
       $this->set('projects', $add_project);
       }
    }
    
    ?>
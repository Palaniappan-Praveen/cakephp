<?php
namespace App\Controller\Hrmadmin;
use App\Controller\AppController;

    class ProjectAllocationsController extends AppController
    {
    
    
       #main function setting all value to view
    
      public function index()
       {
        $this->set('ProjectAllocations',$this->ProjectAllocations->find('all')->contain(['Projects','Employees'])); 
       
       }
       
       #delete function, here we are deleting particular value 
       public function delete($id)

     {

        $this->request->allowMethod(['post', 'delete']);

     

        $project = $this->ProjectAllocations->get($id); 

        if ($this->ProjectAllocations->delete($project)) {

            $this->Flash->success(__('Project Allocation with id: {0} has been deleted.', h($id)));

            return $this->redirect(['action' => 'index']);

        }      

         

    }  
    
    #edit function, and setting particular value for the view 
    public function edit($id)

    {

        $edit_project = $this->ProjectAllocations->get($id);
		#setting value for project list
        $this->set('project_list', $this->ProjectAllocations->Projects->find('list',
                ['keyField'=>'project_id','valueField'=>'project_title','conditions'=>array('status'=>1)]
        ));
		
		#setting value for employee list
        $this->set('employee_list', $this->ProjectAllocations->Employees->find('list',
                ['keyField'=>'employee_id',
				'valueField'=>function ($e) {
            return $e->get('first_name'). ' ' . $e->get('last_name');
        },
				
				'conditions'=>array('status'=>1)]
        ));

        if ($this->request->is(['post', 'put'])) {
        
        $project_id    = trim($this->request->data('project_title'));
		$employee_id   = trim($this->request->data('employee'));
		$comment      = trim($this->request->data('comment'));
        $start_date   = trim($this->request->data('start_date'));
        $end_date     = trim($this->request->data('end_date')); 
          
        
            $data=["project_id"=>$project_id,"employee_id"=>$employee_id,"comment"=>$comment,"start_date"=>$start_date,"end_date"=>$end_date];
            
             #this function checks the validation
             $edit_project = $this->ProjectAllocations->patchEntity($edit_project, $data);

            if ($this->ProjectAllocations->save($edit_project)) {

                $this->Flash->success(__('Project has been updated.'));

                return $this->redirect(['action' => 'index']);

            }

            $this->Flash->error(__('Unable to update Project.'));

        }

     

        $this->set('ProjectAllocations', $edit_project);      

         

    }
    
    
    
    
     #add function,adding value into the database
    
  public function add()
       {
       
        $add_project = $this->ProjectAllocations->newEntity();
        #setting value for project list
        $this->set('project_list', $this->ProjectAllocations->Projects->find('list',
                ['keyField'=>'project_id','valueField'=>'project_title','conditions'=>array('status'=>1)]
        ));
		
		#setting value for employee list
        $this->set('employee_list', $this->ProjectAllocations->Employees->find('list',
                ['keyField'=>'employee_id','valueField'=>function ($e) {
            return $e->get('first_name'). ' ' . $e->get('last_name');
        },
				
				
				'conditions'=>array('status'=>1)]
        ));
		
        if ($this->request->is('post')) {
        $project_id    = trim($this->request->data('project_title'));
		$employee_id   = trim($this->request->data('employee'));
		
        $comment      = trim($this->request->data('comment'));
        $start_date   = trim($this->request->data('start_date'));
        $end_date     = trim($this->request->data('end_date')); 
          
        
            $data=["project_id"=>$project_id,"employee_id"=>$employee_id,"comment"=>$comment,"start_date"=>$start_date,"end_date"=>$end_date];
            
             #this function checks the validation
             $add_project= $this->ProjectAllocations->patchEntity($add_project, $data);
            if($this->ProjectAllocations->save($add_project))
            {
              $this->Flash->success(__('Project Allocation has been saved.'));
             return $this->redirect(["action"=>"index"]);
            }
            else
            {
            $this->Flash->error(__('Project Allocation cannot be saved.'));
            }
        
        
        }
       
       $this->set('ProjectAllocations', $add_project);
       }
    }
    
    ?>
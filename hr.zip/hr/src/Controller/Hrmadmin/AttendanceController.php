<?php
    namespace App\Controller\Hrmadmin;

    use App\Controller\AppController;

    class AttendanceController extends AppController
    {
      
	  public function index()
	   {  
	     
		$attendance            = $this->Attendance->newEntity();
		if ($this->request->is('post')) {
        $uid     			   = $this->Auth->user('employee_id');
        
      
        if($uid )
        {
        $start_date            = trim($this->request->data('time_in'));
        $end_date              = trim($this->request->data('time_out'));

    $query = $this->Attendance->find('all')
 ->where(function($exp)use($start_date,$end_date,$uid) {
        return $exp->between('DATE(time_in)',$start_date,$end_date,'date');})
 ->andWhere([
        'employee_id' => $uid,
        
    ]);




      $current_data = $query->toArray();

          //$current_data = $this->Attendance->find('list',['conditions'=>array('employee_id'=>$uid,'DATE(time_in)>='=>$start_date,'DATE(time_out)<='=>$end_date)]);

       $this->set('current_data',$current_data);
        }
      
        }

		$this->set('attendance',$attendance);
		
	   }


public function hr()
	   {  
	     
		$attendance            = $this->Attendance->newEntity();
		#setting value for employee list
        $this->set('employee_list', $this->Attendance->Employees->find('list',
                ['keyField'=>'employee_id',
				'valueField'=>function ($e) {
            return $e->get('first_name'). ' ' . $e->get('last_name');
        },
				
				'conditions'=>array('status'=>1)]
        ));
		if ($this->request->is('post')) {
        
        
      
        
        
        $uid                   = trim($this->request->data('employee'));	
        $start_date            = trim($this->request->data('time_in'));
        $end_date              = trim($this->request->data('time_out'));

    $query = $this->Attendance->find('all')
 ->where(function($exp)use($start_date,$end_date,$uid) {
        return $exp->between('DATE(time_in)',$start_date,$end_date,'date');})
 ->andWhere([
        'employee_id' => $uid,
        
    ]);




      $current_data = $query->toArray();

          //$current_data = $this->Attendance->find('list',['conditions'=>array('employee_id'=>$uid,'DATE(time_in)>='=>$start_date,'DATE(time_out)<='=>$end_date)]);

       $this->set('current_data',$current_data);
       
        }

		$this->set('attendance',$attendance);
		
	   }

	   
	    public function timein()
	   {  
	   //print_r($_SESSION);
	  
	     $attendance            = $this->Attendance->newEntity();
	     $uid     				= $this->Auth->user('employee_id');
		 $status  				= $this->Auth->user('status');
         $currDateTime 			= date("Y-m-d H:i:s");
         $currentdate           = date("Y-m-d");
		 
		 #checking condition if user login and his status is 1 then only he can perform the task
		 if($uid && $status)
		 {
			 $current_data = $this->Attendance->find('list',
                ['conditions'=>array('employee_id'=>$uid,'DATE(time_in)'=>$currentdate)]
        );
		#checking if already time in
		$number = $current_data->count();
		#if not time in then inserting
		if(!$number)
		{
			$data=["employee_id"=>$uid,"time_in"=>$currDateTime ];
			$attendance= $this->Attendance->patchEntity($attendance, $data);
			$this->Attendance->save($attendance);
		}
		else
		{  $this->Flash->error(__('You have Already Time In'));
			return $this->redirect(['controller'=>'Welcome']);
			
		}
		
			 
			 
		 }
		 else
		 {
			return  $this->redirect($this->Auth->logout()); 
			 
		 }
		$this->Flash->success(__(' Time In Successfully'));
		return $this->redirect(['controller'=>'Welcome']);
	   }
	    public function timeout()
	   {  
	    //print_r($_SESSION);
		
		
	     $uid     				= $this->Auth->user('employee_id');
		 $status  				= $this->Auth->user('status');
         $currDateTime 			= date("Y-m-d H:i:s");
         $currentdate           = date("Y-m-d");
		 
		 #checking condition if user login and his status is 1 then only he can perform the task
		 if($uid && $status)
		 {
			 $current_data = $this->Attendance->find('All',
                ['conditions'=>array('employee_id'=>$uid,'DATE(time_in)'=>$currentdate)]
        );
		#checking if already time in
		$number = $current_data->count();
		#if not time in redirecting user to  welcome Controller
		if(!$number)
		{
			$this->Flash->error(__('Please Check Time in First'));
			return $this->redirect(['controller'=>'Welcome']);
			
		}
		#otherwise checking timeout 
		else
		{
			
			$current_dataout = $this->Attendance->find('list',
                ['conditions'=>array('employee_id'=>$uid,'DATE(time_in)'=>$currentdate,'DATE(time_out)'=>$currentdate)]);
			$numberout = $current_dataout->count();
			
			 
			
			$attendance_id=$current_data->first()->attendance_id;
			
			//echo "d".$current_data->attendance_id;
			#if not timeout enter the value in db

			if(!$numberout)
		   {
			$attendance                  = $this->Attendance->get($attendance_id);
			
			$data                        = ["time_out"=>$currDateTime ];
			$attendance                  = $this->Attendance->patchEntity($attendance, $data);
			$this->Attendance->save($attendance); 
			$this->Flash->success(__(' Time Out Successfully'));
			return $this->redirect(['controller'=>'Welcome']); 
		   }else{  $this->Flash->error(__('You have Already Time Out'));   }
			  
		}
		
			 
			 
		 }
		 else
		 {
			return  $this->redirect($this->Auth->logout()); 
			 
		 }
		
		return $this->redirect(['controller'=>'Welcome']); 
		
		
	   }
	   
	   
    }
	
	
	?>
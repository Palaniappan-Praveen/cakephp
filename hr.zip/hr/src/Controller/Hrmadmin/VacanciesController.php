<?php
namespace App\Controller\Hrmadmin;
use App\Controller\AppController;

    class VacanciesController extends AppController
    {
      #index function . It's default function
public function index()
{
	 $this->set('vacancy',$this->Vacancies->find('all')->contain('designations')); 
	
}


     #adding user
 
 public function add()
    {
        $vacancy = $this->Vacancies->newEntity(); 
		#getting designation list
		$this->set('designation_list', $this->Vacancies->designations->find('list',
                ['keyField'=>'designation_id',
				'valueField'=>'designation_name']
        ));
        if ($this->request->is('post')) { 



		$title   		              = trim($this->request->data('title'));
		$description    		      = trim($this->request->data('description'));
		$designation_id       		  = trim($this->request->data('designation'));
        $qualification_required    	  = trim($this->request->data('qualification_required'));
        $min_exp                      = trim($this->request->data('min_exp')); 
		$max_age                      = trim($this->request->data('max_age'));
		$last_application_date        = trim($this->request->data('last_application_date'));
		$status                       = trim($this->request->data('status'));

		$status                       = $status==1?$status=1:$status=0;
		
$data=["title"=>$title,"description"=>$description,"designation_id"=>$designation_id,"qualification"=>$qualification_required,"experience"=>$min_exp,
"age"=>$max_age,"last_application_date"=>$last_application_date,"status"=>$status];
		 
            // Prior to 3.4.0 $this->request->data() was used.
            $user = $this->Vacancies->patchEntity($vacancy, $data);
            if ($this->Vacancies->save($vacancy)) {
                $this->Flash->success(__('Vacancy has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('Unable to add the Vacancy.'));
        }
        $this->set('vacancy', $vacancy);
    }

        #Editing user
 
 public function edit($id)
    {
        $vacancy = $this->Vacancies->get($id); 
		#getting designation list
		$this->set('designation_list', $this->Vacancies->designations->find('list',
                ['keyField'=>'designation_id',
				'valueField'=>'designation_name']
        ));
       if ($this->request->is(['post', 'put'])) {



		$title   		              = trim($this->request->data('title'));
		$description    		      = trim($this->request->data('description'));
		$designation_id       		  = trim($this->request->data('designation'));
        $qualification_required    	  = trim($this->request->data('qualification_required'));
        $min_exp                      = trim($this->request->data('min_exp')); 
		$max_age                      = trim($this->request->data('max_age'));
		$last_application_date        = trim($this->request->data('last_application_date'));
		$status                       = trim($this->request->data('status'));

		$status                       = $status==1?$status=1:$status=0;
		
$data=["title"=>$title,"description"=>$description,"designation_id"=>$designation_id,"qualification"=>$qualification_required,"experience"=>$min_exp,
"age"=>$max_age,"last_application_date"=>$last_application_date,"status"=>$status];
		 
            // Prior to 3.4.0 $this->request->data() was used.
            $user = $this->Vacancies->patchEntity($vacancy, $data);
            if ($this->Vacancies->save($vacancy)) {
                $this->Flash->success(__('Vacancy has been Updated.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('Unable to Update the Vacancy.'));
        }
        $this->set('vacancy', $vacancy);
    }



    }
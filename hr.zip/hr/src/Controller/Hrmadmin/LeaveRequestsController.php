<?php
namespace App\Controller\Hrmadmin;
use App\Controller\AppController;

    class LeaveRequestsController extends AppController
    {
	 
	 
	 
	 
	 
	public function index()
       {
	   #checking user id status and role
	   #only employee can do this task
	    $uid     				= $this->Auth->user('employee_id');

        $this->set('leave',$this->LeaveRequests->find('all',['conditions'=>array('employee_id'=>$uid)])); 
       
       }
	   
	   public function add()
	   {
	   #checking user id status and role
	   #only employee can do this task
	    $leave                  = $this->LeaveRequests->newEntity();
	    $uid     				= $this->Auth->user('employee_id');
	    $status    		        = $this->Auth->user('status');
	    $role    				= $this->Auth->user('role');
	   if ($this->request->is('post')) {
        $leavefrom        = trim($this->request->data('leave_from'));
        $leaveto          = trim($this->request->data('leave_to'));
		$reason           = trim($this->request->data('reason'));
		if($uid!='')
		{
		
            $data=["leave_from"=>$leavefrom,"leave_to"=>$leaveto,"reason"=>$reason,"employee_id"=>$uid];
            
            #this function checks the validation
             $leave= $this->LeaveRequests->patchEntity($leave, $data);
            if($this->LeaveRequests->save($leave))
            {
             $this->Flash->success(__('Leave Request has been sent.'));
             return $this->redirect(['controller' => 'leave_requests',"action"=>"/"]);
            }
		
		}else
		{
		return  $this->redirect($this->Auth->logout()); 
		}
	   
		
		}
	   
	   
	   $this->set('leave', $leave);
	   
	   }
	   
	     #edit function, and setting particular value for the view  this is only for employee
    public function edit($id)

    {
	    
       $uid    = $this->Auth->user('employee_id');
    $leave = $this->LeaveRequests->find('all', [ // or 'first'
    'conditions' => ['leave_id' => $id,'employee_id'=>$uid]
    
]);
      $leave=$leave->first();
		

        if ($this->request->is(['post', 'put'])) {
		$status=  $leave->status;
		#if status pending only
        if($status==0)
		{
        $leavefrom        = date('Y-m-d',strtotime(trim($this->request->data('leave_from'))));
        $leaveto          = date('Y-m-d',strtotime(trim($this->request->data('leave_to'))));
		$reason           = trim($this->request->data('reason'));
		
        $data=["leave_from"=>$leavefrom,"leave_to"=>$leaveto,"reason"=>$reason,];

          $leave= $this->LeaveRequests->patchEntity($leave, $data);
             //update data with condition
            if ($this->LeaveRequests->updateAll($data,["employee_id"=>$uid,'leave_id' => $id])) {

                $this->Flash->success(__('Leave Request has been updated.'));

                return $this->redirect(['action' => 'index']);

            }

            $this->Flash->error(__('Unable to update Leave Request.'));
         }
		 else
		 {
		 $this->Flash->error(__('Unable to update Leave Request.'));
		 }
        }

     

        $this->set('leave', $leave);      

         

    }
	   
	   #this is for hr edit only for changing status
	   public function hredit($id)
    {
	$leave    = $this->LeaveRequests->find('all', ['conditions' => ['leave_id' => $id]]);
	$leave    = $leave->first();
     $role    = $this->Auth->user('role');
	  if ($this->request->is(['post', 'put'])) {
	 
	  
      
	  $status           = trim($this->request->data('status'));
	  $data             =["status"=>$status,];

          $leave= $this->LeaveRequests->patchEntity($leave, $data);
             
            if ($this->LeaveRequests->save($leave)) {

                $this->Flash->success(__('Leave Status has been updated.'));

                return $this->redirect(['controller' => 'welcome',"action"=>"/"]);

            }
	  
	  $this->Flash->error(__('Unable to update Leave Status.'));
	 
	 
	 
    }
	
	$this->set('leave', $leave); 
	}
	   
	   
	   
	        #delete function, here we are deleting particular value with selected user
       public function delete($id)

      {

        $this->request->allowMethod(['post', 'delete']);
        $uid     	 = $this->Auth->user('employee_id');
        
		
        if ($this->LeaveRequests->deleteAll(['employee_id'=>$uid,'leave_id'=>$id,'status'=>0])) {

            $this->Flash->success(__('Leave Request with id: {0} has been deleted.', h($id)));

            return $this->redirect(['action' => 'index']);

        }
         else
        {
		$this->Flash->error(__('You Cannot Delete this'));

            return $this->redirect(['action' => 'index']);

          }		

         

    } 
	
	
	}
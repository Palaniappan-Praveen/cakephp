<?php
namespace App\Controller\Hrmadmin;
use App\Controller\AppController;
use Cake\Event\Event;
class UsersController extends AppController
{
public function beforeFilter(Event $event) {
            parent::beforeFilter($event);
            
			
			 $this->Auth->allow(['loginajax','logincheck']);
       }


#index function . It's default function
public function index()
{
	 $this->set('employees',$this->Users->find('all')->contain('designations')); 
	
}

#adding user
 
 public function add()
    {
        $user = $this->Users->newEntity(); 
		#getting designation list
		$this->set('designation_list', $this->Users->designations->find('list',
                ['keyField'=>'designation_id',
				'valueField'=>'designation_name']
        ));
        if ($this->request->is('post')) { 
		$first_name   		 = trim($this->request->data('first_name'));
		$last_name    		 = trim($this->request->data('last_name'));
		$address       		 = trim($this->request->data('address'));
        $contact_no    		 = trim($this->request->data('contact_no'));
        $joining_date        = trim($this->request->data('joining_date')); 
		$username            = trim($this->request->data('username'));
		$password            = trim($this->request->data('password'));
		$basic_pay           = trim($this->request->data('basic_pay'));
		$designation_id      = trim($this->request->data('designation'));
		$status              = trim($this->request->data('status'));
		$create_date         = date('Y-m-d H:i:s');
		$status              = $status==1?$status=1:$status=0;
		$role                = trim($this->request->data('role'));  
		
$data=["first_name"=>$first_name,"last_name"=>$last_name,"address"=>$address,"contact_no"=>$contact_no,"joining_date"=>$joining_date,
"username"=>$username,"password"=>$password,"basic_pay"=>$basic_pay,"designation_id"=>$designation_id,"status"=>$status,"create_date"=>$create_date,"role"=>$role];
		 
            // Prior to 3.4.0 $this->request->data() was used.
            $user = $this->Users->patchEntity($user, $data);
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('Unable to add the user.'));
        }
        $this->set('user', $user);
    }

 

#editing user
 
 public function edit($id)
    {
        $user = $this->Users->get($id); 

        #getting designation list
        $this->set('designation_list', $this->Users->designations->find('list',
                ['keyField'=>'designation_id',
                'valueField'=>'designation_name']
        ));
        if ($this->request->is(['post', 'put'])) {
        $first_name          = trim($this->request->data('first_name'));
        $last_name           = trim($this->request->data('last_name'));
        $address             = trim($this->request->data('address'));
        $contact_no          = trim($this->request->data('contact_no'));
        $joining_date        = trim($this->request->data('joining_date')); 
        $username            = trim($this->request->data('username'));
        $password            = trim($this->request->data('password'));
        $basic_pay           = trim($this->request->data('basic_pay'));
        $designation_id      = trim($this->request->data('designation'));
        $status              = trim($this->request->data('status'));
        $create_date         = date('Y-m-d H:i:s');
        $status              = $status==1?$status=1:$status=0;
        $role                = trim($this->request->data('role'));  
        
$data=["first_name"=>$first_name,"last_name"=>$last_name,"address"=>$address,"contact_no"=>$contact_no,"joining_date"=>$joining_date,
"username"=>$username,"password"=>$password,"basic_pay"=>$basic_pay,"designation_id"=>$designation_id,"status"=>$status,"create_date"=>$create_date,"role"=>$role];
         
            // Prior to 3.4.0 $this->request->data() was used.
            $user = $this->Users->patchEntity($user, $data);
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been Updated successfully.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('Unable to Update the user.'));
        }
        $this->set('user', $user);
    }

#delete function, here we are deleting particular value 
       public function delete($id)

     {

        $this->request->allowMethod(['post', 'delete']);

     

        $eid = $this->Users->get($id);

        if ($this->Users->delete($eid)) {

            $this->Flash->success(__('The Employee with id: {0} has been deleted.', h($id)));

            return $this->redirect(['action' => 'index']);

        }      

         

    }
 
  public function login()
    {
        
       if(!$this->request->session()->read('Auth.User.employee_id')) #check user already login 
       {

        if ($this->request->is('post')) {
            $user = $this->Auth->identify();
            if ($user) {
               
                $status= $user['status'];
                if($status==1)
                 {
                $this->Auth->setUser($user);
                return $this->redirect($this->Auth->redirectUrl());
                 }
                 else
                 {
                  $this->Flash->error(__('Your Account Is Inactive'));

                 }
            }
            else
            {
            $this->Flash->error(__('Invalid username or password, try again'));
          }
        }
    } else { return $this->redirect($this->Auth->redirectUrl());    }
    }
    public function logincheck()
    {
        $this -> autoRender = false; 

    if ($this->request->is('post')) {
        
            if(!$this->request->session()->read('Auth.User.employee_id')) #check user already login 
              {
            $user = $this->Auth->identify();
            if ($user) {
                 $status= $user['status'];
                if($status==1)
                 {

                $this->Auth->setUser($user);
                echo  1; #if user is correct and status is active
                exit;
                 }
                 else
                 {

                    echo 3;exit; #Account is deactivate;
                 }

            }
            else
            {
                echo 2;  #if username and password is wrong
                exit; 
            }
         
        }
        else
      {
      echo 4;
      exit;

      }
      }
      

    }
 
  public function loginajax()
    {
        
        
    
    }

 public function logout(){

        $this->Flash->success('You successfully have logged out');

       return  $this->redirect($this->Auth->logout());

    }

 
 
 
}


?>

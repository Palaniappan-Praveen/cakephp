<?php
   namespace App\Controller;
   use App\Controller\AppController;
  use Cake\Event\Event;
   class VacanciesController extends AppController{
     
       public function beforeFilter(Event $event) {
            parent::beforeFilter($event);
            if ($this->request->is('ajax')) {
                    $this->response->disableCache();
            }
			 $this->Auth->allow();
			
			
        }

    public function index()
     {
	 $this->set('vacancy',$this->Vacancies->find('all' ,['conditions'=>array('status'=>1)])->contain('designations')); 
	
     }
     public function apply($id)
     {


           #checking job available or not with staus 1
      $this -> autoRender = false; 
      if($id!='' && is_numeric($id))
      {
       $current_data = $this->Vacancies->find('list',
                ['conditions'=>array('status'=>1,'vacancy_id'=>$id)]);

        $number = $current_data->count();
        $applicants = $this->Vacancies->applicants->newEntity(); 
          if($number)
           {



            $this -> autoRender = true; 

           $this->set('id',$id);

           $this->set('applicants', $applicants);

           }
        
      }

        }

 #jobapply function
     	
    public function jobapplyajax()
	{
	 $this -> autoRender = false; 
	 if ($this->request->is('post')) {
	 
	 
	   $first_name          	= trim($this->request->data('first_name'));
	   $last_name           	= trim($this->request->data('last_name'));
	   $vacancy_id              = trim($this->request->data('vacancy_id'));
	   $contact_no              = trim($this->request->data('contact_no'));
	   $email_id            	= trim($this->request->data('email_id'));
	   $qualification           = trim($this->request->data('qualification'));
	   $date_of_birth           = trim($this->request->data('date_of_birth'));
	   $gender                  = trim($this->request->data('Gender'));
	   $experience              = trim($this->request->data('experience'));
	   $expectation             = trim($this->request->data('salary_expectation'));
	   $date                    = date('Y-m-d');
	   #checking vacancy id is not null
	   
	   $data=["first_name"=>$first_name,"last_name"=>$last_name,"vacancy_id"=>$vacancy_id,"contact_no"=>$contact_no,"email_id"=>$email_id,
"qualification"=>$qualification,"date_of_birth"=>$date_of_birth,"gender"=>$gender,"experience"=>$experience,"salary_expectation"=>$expectation,"application_date"=>$date];
	   if(!empty($vacancy_id) && is_numeric($vacancy_id))
      {
       $current_data = $this->Vacancies->find('list',
                ['conditions'=>array('status'=>1,'vacancy_id'=>$vacancy_id)]);

        $number   = $current_data->count();
        
          if($number)
           {
                $applyfor = $this->Vacancies->applicants->newEntity(); 
				
                $applyfor = $this->Vacancies->applicants->patchEntity($applyfor, $data);
            if ($this->Vacancies->applicants->save($applyfor)) {
			echo 1;
			exit;
			}
			else
			{
			if($applyfor->errors()){
                //$error_msg = [];
				foreach( $applyfor->errors() as $errors){
                    if(is_array($errors)){
                        foreach($errors as $error){
                            echo '<p>'.$error.'</p>';
                        }
                    }else{
                       echo '<p>'.$errors.'</p>';
                    }
               
				}
			
			}
			 
           }
		   }
		   else
		   {
		   echo "you Cannot apply for this job";
		   }
        
      }
	 else
	 {
	 
	 echo "UnAuthorize access";
	 
	 }
	
	
	}
	}
      
   }
?>
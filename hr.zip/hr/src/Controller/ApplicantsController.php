<?php
   namespace App\Controller;
   use App\Controller\AppController;
  use Cake\Event\Event;
   class ApplicantsController extends AppController{
     
       public function beforeFilter(Event $event) {
            parent::beforeFilter($event);
            if ($this->request->is('ajax')) {
                    $this->response->disableCache();
            }
			
			 $this->Auth->allow();
        }


	
	
	}
	?>
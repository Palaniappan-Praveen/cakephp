<?php
namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class UsersTable extends Table
{
  public function initialize(array $config) {
        $this->setTable('employees');
		$this->belongsTo('designations');

        // Prior to 3.4.0 use 'table' method
        // $this->table('my_table');
    }
  public function validationDefault(Validator $validator)
    {
        return $validator
     
     ->add('username', [
 'unique' => ['rule' => 'validateUnique', 'provider' => 'table',"message"=>"This username you have already used"]
])
     ->notEmpty('first_name', 'First Name is required')
     ->notEmpty('last_name', 'Last Name is required')
     ->notEmpty('designation', 'Designation is Required')
     ->notEmpty('address', 'Address is required')
     ->notEmpty('contact_no', 'Contact Number is required')
     
      ->notEmpty('joining_date', 'Contact Number is required')
         ->notEmpty('username', 'A username is required')
         ->notEmpty('password', 'A password is required')
       ->notEmpty('basic_pay', 'Basic Pay is required')
		 
	     
            ->add('role', 'inList', [
                'rule' => ['inList', ['admin', 'employee','hr']],
                'message' => 'Please enter a valid role'
            ]); 
    }


     
  

}  
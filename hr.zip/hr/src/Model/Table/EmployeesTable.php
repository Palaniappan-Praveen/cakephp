<?php
namespace App\Model\Table;

use Cake\ORM\Table;

class EmployeesTable extends Table
{

}


?>
<?php
namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;
class ProjectsTable extends Table
{
  
  public function validationDefault(Validator $validator)
    {
        return $validator
        ->notEmpty('project_title', 'Project Title is required')
        ->notEmpty('start_date', 'Start Date is required')
        ->notEmpty('end_date', 'End Date is required');
            
           
            
    }
  

}
<?php
namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;
class WelcomeTable extends Table
{
  public function initialize(array $config) {
        $this->setTable('employees');
        $this->belongsTo('Attendance'); 
		$this->belongsTo('leaveRequests')
		 ->setForeignKey('employee_id')
		// 'conditions' => 'leaveRequests.employee_id = employees.employees_id'
          ->setJoinType('INNER');		
	 
        // Prior to 3.4.0 use 'table' method
        // $this->table('my_table');
    }
  
  

}
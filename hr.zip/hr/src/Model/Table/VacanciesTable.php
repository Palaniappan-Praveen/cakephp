<?php
namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;
class VacanciesTable extends Table
{
   public function initialize(array $config)
    {
        $this->belongsTo('designations');
        $this->belongsTo('applicants');
        
    }
  
  public function validationDefault(Validator $validator)
    {
        return $validator
        ->add('min_exp','numeric',array('rule' => 'numeric' ,'message'=> 'Experience Should be in Years'))
   
->add('max_age','numeric',array('rule' => 'numeric' ,'message'=> 'Age Should be in Years'))
        ->notEmpty('title', 'Title is required')
		->notEmpty('description', 'Description is required')
        ->notEmpty('designation', 'Designation is required')
        ->notEmpty('qualification_required', 'Qualification is required')
        ->notEmpty('min_exp', 'Minimum Experience is required')
        ->notEmpty('max_age', 'Max Age is required')
        ->notEmpty('last_application_date', 'Last Application is required');
            
            
    }
  
   public function register1(Validator $validator)
	{
	return $validator
	->notEmpty('first_name', 'First is required');
	
	
	}
  
  
}
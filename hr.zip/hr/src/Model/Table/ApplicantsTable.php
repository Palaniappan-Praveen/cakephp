<?php
namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;
class ApplicantsTable extends Table
{
   public function initialize(array $config)
    {
        $this->belongsTo('vacancies');
        
        
    }
  
  public function validationDefault(Validator $validator)
    {
        return $validator
        ->notEmpty('first_name', 'First Name is required')
		->notEmpty('last_name',   'Last Name is required')
		->notEmpty('contact_no',   'Contact No is required')
		->notEmpty('vacancy_id',   'Vacancy Id is required')
		->notEmpty('email_id',   'Email Id is required')
        ->notEmpty('qualification', 'Qualification is required')
        ->notEmpty('date_of_birth', 'Date Of Birth is required')
		->add('Gender', 'inList', [
                'rule' => ['inList', ['male', 'female']],
                'message' => 'Please Select Gender'
            ])
        ->notEmpty('experience', 'Experience is required')
        ->notEmpty('salary_expectation', 'Salary Expectation is required');
            
			
            
    }
	
	
  

}
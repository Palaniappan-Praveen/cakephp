<?php
namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;
class LeaveRequestsTable extends Table
{
   
   public function initialize(array $config) {
       
        $this->belongsTo('employees'); 
		
    }
  public function validationDefault(Validator $validator)
    {
        return $validator
        ->notEmpty('leave_from', 'Leave From is required')
        ->notEmpty('leave_to', 'Leave To is required')
		->notEmpty('reason', 'Reason is required');
            
           
            
    }
  

}
<?php
namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;
class DesignationsTable extends Table
{
  
  public function validationDefault(Validator $validator)
    {
        return $validator
        ->notEmpty('designation_name', 'Designation Name is required');
            
           
            
    }
  

}
<?php 
class Product extends AppModel{
	public $name = 'product';
	public $primaryKey = 'product_id';
}//end of class
?>
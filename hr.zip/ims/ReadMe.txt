1. Create the database and all the tables. 
2. You need to add a record manually to the "users" table as the application checks for the user in the users database.
2. Copy each file to the exactly corresponding folder in your cakephp setup. MAKE SURE TO BACKUP ANY EXISTING FILES BEFORE OVERWRITING. 
3. Change the database setting in database.php file as per your mysql setup
4. Enter base URL for your cakePHP.
